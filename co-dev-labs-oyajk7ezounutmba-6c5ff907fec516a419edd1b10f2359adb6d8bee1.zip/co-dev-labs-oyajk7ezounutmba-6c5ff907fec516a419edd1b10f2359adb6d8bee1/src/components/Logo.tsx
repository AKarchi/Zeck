import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="text-xl font-bold">Logo</div>
  );
};

export default Logo;
